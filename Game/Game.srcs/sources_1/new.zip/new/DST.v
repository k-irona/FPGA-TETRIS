`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/12/09 19:53:17
// Design Name: 
// Module Name: DST
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module DST (
    input                   [ 0 : 0]            rstn,
    input                   [ 0 : 0]            pclk,

    output      reg         [ 0 : 0]            hen,        // ˮƽ��ʾ��Ч
    output      reg         [ 0 : 0]            ven,        // ��ֱ��ʾ��Ч
    output      reg         [ 0 : 0]            hs,         // ��ͬ��
    output      reg         [ 0 : 0]            vs          // ��ͬ��
);

localparam HSW_t    = 119;
localparam HBP_t    = 63;
localparam HEN_t    = 799;
localparam HFP_t    = 55;

localparam VSW_t    = 5;
localparam VBP_t    = 22;
localparam VEN_t    = 599;
localparam VFP_t    = 36;

localparam SW       = 2'b00;
localparam BP       = 2'b01;
localparam EN       = 2'b10;    
localparam FP       = 2'b11;

reg     [ 0 : 0]    ce_v;

reg     [ 1 : 0]    h_state;
reg     [ 1 : 0]    v_state;

reg     [15 : 0]    d_h;
reg     [15 : 0]    d_v;

wire    [15 : 0]    q_h;
wire    [15 : 0]    q_v;

CntS #(16,HSW_t) hcnt(          // ÿ��ʱ�����ڼ���������1����ʾɨ��һ������
    .clk        (pclk),
    .rstn       (rstn),
    .d          (d_h),
    .ce         (1'b1),

    .q          (q_h)
);

CntS #(16,VSW_t) vcnt(          // ÿ��ɨ�������������1����ʾɨ��һ�����ص�
    .clk        (pclk),
    .rstn       (rstn),
    .d          (d_v),
    .ce         (ce_v),

    .q          (q_v)
);                              // ��ʾ��˼��һ�¼���ʹ������

always @(*) begin
    case (h_state)
        SW: begin
            d_h = HBP_t;  hs = 1; hen = 0;
        end
        BP: begin
            d_h = HEN_t;  hs = 0; hen = 0;
        end
        EN: begin
            d_h = HFP_t;  hs = 0; hen = 1;
        end
        FP: begin
            d_h = HSW_t;  hs = 0; hen = 0;
        end
    endcase
    case (v_state)
        SW: begin
            d_v = VBP_t;  vs = 1; ven = 0;
        end
        BP: begin
            d_v = VEN_t;  vs = 0; ven = 0;
        end
        EN: begin
            d_v = VFP_t;  vs = 0; ven = 1;
        end
        FP: begin
            d_v = VSW_t;  vs = 0; ven = 0;
        end
    endcase
end

always @(posedge pclk) begin
    if (!rstn) begin
        h_state <= SW; v_state <= SW; ce_v <= 1'b0;
    end
    else begin
        if(q_h == 0) begin
            h_state <= h_state + 2'b01;
            if (h_state == FP) begin
                ce_v <= 0;
                if (q_v == 0)
                    v_state <= v_state + 2'b01;
            end
            else
                ce_v <= 0;
        end
        else if (q_h == 1) begin
            if(h_state == FP)
                ce_v <= 1;
            else
                ce_v <= 0;
        end
        else ce_v <= 0;
    end
end
endmodule
